/*
 * author:   Junbo Zhang
 * homepage: http://cs.gsu.edu/~jbzhang/
 * e-mail:   JunboZhang@163.com
 * paper:    Junbo Zhang, Tianrui Li, Yi Pan, 
 *           Parallel rough set based knowledge acquisition using MapReduce from big data. 
 *           ACM SIGKDD12 Big Data Mining (BigMine'12) Workshop, Beijing, China, pp. 20-27,2012.
 */

package cn.edu.swjtu.sist.rs.rule;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import org.apache.hadoop.conf.*;
import org.apache.hadoop.util.*;

import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class Rule extends Configured implements Tool {

	public void printUsage() {
		System.out
				.print("-i input_path_in_HDFS \n"
						+ "-i output_path_in_HDFS \n"
						+ "-as start_attribute [interger & >= 2, the first column is the Line_ID] \n"
						+ "-ae end_attribute [interger & >= as] \n"
						+ "ex.: $HADOOP_HOME/bin/hadoop jar *.jar MainClass -i kdd99_input -o kdd99_output -as 2 -ae 42 \n");
	}

	public int run(String[] args) throws Exception {
		int i;
		int NumTasks = 1;
		double alpha = 0.6, beta = 0.1;
		String input_path = "input", output_path = "output", as = "", ae = "";
		if (args.length < 6) {
			System.out.println("command error!");
			printUsage();
			System.exit(0);
		}
		for (i = 0; i < args.length; ++i) // && args[i].startsWith("-")
		{
			if (args[i].startsWith("-") == false) {
				System.out.println("command error!");
				printUsage();
				System.exit(0);
			}
			if (args[i].equals("-i")) {
				input_path = args[++i];
			} else if (args[i].equals("-o")) {
				output_path = args[++i];
			} else if (args[i].equals("-as")) {
				i++;
				// ATTR.as = Integer.parseInt(args[i]);
				as = args[i];
			} else if (args[i].equals("-ae")) {
				i++;
				// ATTR.ae = Integer.parseInt(args[i]);
				ae = args[i];
			} else if (args[i].equals("-n")) {
				i++;
				NumTasks = Integer.parseInt(args[i]);
			}
		}

		if (Integer.parseInt(as) <= 0
				|| Integer.parseInt(as) > Integer.parseInt(ae)
				|| input_path.length() < 1 || output_path.length() < 1) {
			System.out.println("command error!");
			printUsage();
			System.exit(0);
		}

		Configuration conf = new Configuration();
		conf.set("as_as", as);
		conf.set("ae_ae", ae);

		Job job = new Job(conf, "CalcAx");
		job.setJarByClass(Rule.class);
		job.setMapperClass(cn.edu.swjtu.sist.rs.ec.ECMap.class);
		job.setCombinerClass(cn.edu.swjtu.sist.rs.ec.ECReduceCount.class);
		job.setReducerClass(cn.edu.swjtu.sist.rs.ec.ECReduceCount.class);
		job.setNumReduceTasks(NumTasks);

		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);

		FileInputFormat.addInputPath(job, new Path(input_path));
		FileOutputFormat.setOutputPath(job, new Path(output_path));

		job.waitForCompletion(true);
		getRules(new Path(output_path), conf, alpha, beta);

		return 0;
	}

	public static void main(String[] args) throws Exception {
		int res = ToolRunner.run(new Configuration(), new Rule(), args);
		System.exit(res);
	}

	public int getRules(Path input_path, Configuration conf, double alpha,
			double beta) throws Exception {
		FileSystem fs = FileSystem.get(conf);
		FileStatus fileList[] = fs.listStatus(input_path);
		/*
		 * D: the number of each Decision Class. Key: the information set of Dj;
		 * value: the number
		 */
		HashMap<String, Integer> D = new HashMap<String, Integer>();
		/*
		 * E: the number of each Equivalence Class. Key: the information set of
		 * Ei; value: the number
		 */
		HashMap<String, Integer> E = new HashMap<String, Integer>();
		/*
		 * Ass: the assiciations. Key: the information set of Dj; value: the
		 * list of Ek with Dj. Ass(Ek, Dj) = True
		 */
		HashMap<String, Integer> F = new HashMap<String, Integer>();

		for (int j = 0; j < fileList.length; ++j) {
			String sT = fileList[j].getPath().toString();
			if (sT.length() <= 0)
				continue;
			if (sT.charAt(sT.length() - 1) < '0'
					|| sT.charAt(sT.length() - 1) > '9')
				continue;
			FSDataInputStream in = fs.open(fileList[j].getPath());
			Scanner sc = new Scanner(in);
			String tmp;
			
			while (sc.hasNextLine()) {
				tmp = sc.nextLine();
				int t=0;
				for(t=tmp.length()-1;t>=0;--t)
					if(tmp.charAt(t) == ']') break;
				String tmpK="", tmpV="";
				tmpK = tmp.substring(0,t+1);
				for(;t<tmp.length();++t)
					if(tmp.charAt(t)<='9' && tmp.charAt(t) >='0') break;
				for(;t<tmp.length();++t)
				{
					if(tmp.charAt(t)>'9' || tmp.charAt(t) <'0') break;
					tmpV += tmp.charAt(t);
				}
				//tmp = sc.next();
				//num = sc.nextInt();
				if (tmpK.startsWith("F")) {
					F.put(tmpK.substring(1), new Integer(tmpV));
				} else if (tmpK.startsWith("d")) {
					D.put(tmpK.substring(1), new Integer(tmpV));
				} else if (tmpK.startsWith("e")) {
					E.put(tmpK.substring(1), new Integer(tmpV));
				}
			}
		}

		// System.out
		// .println("          Decision | Cardinality of Decision Class | Cardinality of Lower Approximation | Cardinality of Upper Approximation");
		System.out.println("E --> D Accuracy Coverage");
		for (Map.Entry<String, Integer> entry : F.entrySet()) {
			String Key = entry.getKey();
			Integer Value = entry.getValue();
			int t = 0;
			for (t = Key.length() - 1; t >= 0; --t) {
				if (Key.charAt(t) == '[')
					break;
			}
			String cond = Key.substring(0, t);
			String deci = Key.substring(t);
			double acc = 0, cov = 0;
			if (E.containsKey(cond)) {
				if(E.get(cond)>0) acc = 1.0 * Value / E.get(cond);
			}
			if (D.containsKey(deci)) {
				if(D.get(deci)>0)  cov = 1.0 * Value / D.get(deci);
			}
			System.out.printf("%s --> %s  acc=%.6f  cov=%.6f \n", cond, deci, acc, cov);
		}

		return 0;
	}
}
