/*
 * author:   Junbo Zhang
 * homepage: http://cs.gsu.edu/~jbzhang/
 * e-mail:   JunboZhang@163.com
 * paper:    Junbo Zhang, Tianrui Li, Da Ruan, Zizhe Gao, Chengbing Zhao, 
 *           A Parallel Method for Computing Rough Set Approximations, 
 *           Information Sciences, vol. 194, pp. 209-223, 2012.
 */

package cn.edu.swjtu.sist.rs.appr;

import java.util.*;

import org.apache.hadoop.conf.*;
import org.apache.hadoop.util.*;

import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class Appr extends Configured implements Tool {

	public void printUsage() {
		System.out
				.print("-i input_path_in_HDFS \n"
						+ "-i output_path_in_HDFS \n"
						+ "-as start_attribute [interger & >= 2, the first column is the Line_ID] \n"
						+ "-ae end_attribute [interger & >= as] \n"
						+ "ex.: $HADOOP_HOME/bin/hadoop jar *.jar MainClass -i kdd99_input -o kdd99_output -as 2 -ae 42 \n");
	}

	public int run(String[] args) throws Exception {
		int i;
		int NumTasks = 1;
		String MapTasksMax = "2";
		String ReduceTasksMax = "2";
		String input_path = "", output_path = "", as = "", ae = "";
		if (args.length < 6) {
			System.out.println("command error!");
			printUsage();
			System.exit(0);
		}
		for (i = 0; i < args.length; ++i) // && args[i].startsWith("-")
		{
			if (args[i].startsWith("-") == false) {
				System.out.println("command error!");
				printUsage();
				System.exit(0);
			}
			if (args[i].equals("-i")) {
				input_path = args[++i];
			} else if (args[i].equals("-o")) {
				output_path = args[++i];
			} else if (args[i].equals("-as")) {
				i++;
				// ATTR.as = Integer.parseInt(args[i]);
				as = args[i];
			} else if (args[i].equals("-ae")) {
				i++;
				// ATTR.ae = Integer.parseInt(args[i]);
				ae = args[i];
			} else if (args[i].equals("-n")) {
				i++;
				NumTasks = Integer.parseInt(args[i]);
			} else if (args[i].equals("-MapNumMax")) {
				i++;
				MapTasksMax = args[i];
			} else if (args[i].equals("-ReduceNumMax")) {
				i++;
				ReduceTasksMax = args[i];
			}
		}

		if (Integer.parseInt(as) <= 0
				|| Integer.parseInt(as) > Integer.parseInt(ae)
				|| input_path.length() < 1 || output_path.length() < 1) {
			System.out.println("command error!");
			printUsage();
			System.exit(0);
		}

		Configuration conf = new Configuration();
		conf.set("as_as", as);
		conf.set("ae_ae", ae);
		conf.set("mapred.tasktracker.map.tasks.maximum", MapTasksMax);
		conf.set("mapred.tasktracker.reduce.tasks.maximum", ReduceTasksMax);

		Job job = new Job(conf, "Calc Appr");
		job.setJarByClass(Appr.class);
		job.setMapperClass(cn.edu.swjtu.sist.rs.ec.ECMap.class);
		job.setCombinerClass(cn.edu.swjtu.sist.rs.ec.ECReduce.class);
		job.setReducerClass(cn.edu.swjtu.sist.rs.ec.ECReduce.class);
		job.setNumReduceTasks(NumTasks);

		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);

		FileInputFormat.addInputPath(job, new Path(input_path));
		FileOutputFormat.setOutputPath(job, new Path(output_path));

		job.waitForCompletion(true);
		calc_Ax(new Path(output_path), conf);

		return 0;
	}

	public static void main(String[] args) throws Exception {
		int res = ToolRunner.run(new Configuration(), new Appr(), args);
		System.exit(res);
	}

	public int calc_Ax(Path input_path, Configuration conf) throws Exception {
		FileSystem fs = FileSystem.get(conf);
		FileStatus fileList[] = fs.listStatus(input_path);
		/*
		 * D: the number of each Decision Class. Key: the information set of Dj;
		 * value: the number
		 */
		HashMap<String, Integer> D = new HashMap<String, Integer>();
		/*
		 * E: the number of each Equivalence Class. Key: the information set of
		 * Ei; value: the number
		 */
		HashMap<String, Integer> E = new HashMap<String, Integer>();
		/*
		 * Ass: the assiciations. Key: the information set of Dj; value: the
		 * list of Ek with Dj. Ass(Ek, Dj) = True
		 */
		HashMap<String, ArrayList<String>> Ass = new HashMap<String, ArrayList<String>>();
		/*
		 * CountE: the number. Key: the information set of Ei; the number of Dk
		 * with Ei, if 1 means Lower Appr; else no.
		 */
		HashMap<String, Integer> CountE = new HashMap<String, Integer>();
		for (int j = 0; j < fileList.length; ++j) {
			String sT = fileList[j].getPath().toString();
			if (sT.length() <= 0)
				continue;
			if (sT.charAt(sT.length() - 1) < '0'
					|| sT.charAt(sT.length() - 1) > '9')
				continue;
			FSDataInputStream in = fs.open(fileList[j].getPath());
			Scanner sc = new Scanner(in);
			String tmp, deci, cond, num;
			while (sc.hasNextLine()) {
				tmp = sc.nextLine();
				deci = "";
				cond = "";
				num = "";
				int k;
				if (tmp.startsWith("F")) {
					for (k = 0; k < tmp.length(); ++k) {
						if (tmp.charAt(k) == '[')
							break;
					}
					cond = "";
					for (++k; k < tmp.length(); ++k) {
						if (tmp.charAt(k) == ']')
							break;
						cond += tmp.charAt(k);
					}
					for (++k; k < tmp.length(); ++k) {
						if (tmp.charAt(k) == '[')
							break;
					}
					deci = "";
					for (++k; k < tmp.length(); ++k) {
						if (tmp.charAt(k) == ']')
							break;
						deci += tmp.charAt(k);
					}
					// Ass
					if (Ass.containsKey(deci)) {
						ArrayList<String> dest = new ArrayList<String>(
								Ass.get(deci));
						dest.add(cond);
						Ass.put(deci, dest);
					} else {
						ArrayList<String> dest = new ArrayList<String>();
						dest.add(cond);
						Ass.put(deci, dest);
					}

					// CountE
					if (CountE.containsKey(cond)) {
						Integer dest = new Integer(CountE.get(cond) + 1);
						CountE.put(cond, dest);
					} else {
						CountE.put(cond, new Integer(1));
					}

				} else if (tmp.startsWith("d")) {
					for (k = 0; k < tmp.length(); ++k) {
						if (tmp.charAt(k) == '[')
							break;
					}
					deci = "";
					for (++k; k < tmp.length(); ++k) {
						if (tmp.charAt(k) == ']')
							break;
						deci += tmp.charAt(k);
					}

					for (++k; k < tmp.length(); ++k) {
						if (tmp.charAt(k) <= '9' && tmp.charAt(k) >= '0')
							break;
					}
					num = "";
					for (; k < tmp.length(); ++k) {
						if (tmp.charAt(k) > '9' || tmp.charAt(k) < '0')
							break;
						num += tmp.charAt(k);
					}
					D.put(deci, new Integer(num));
				} else if (tmp.startsWith("e")) {
					for (k = 0; k < tmp.length(); ++k) {
						if (tmp.charAt(k) == '[')
							break;
					}
					cond = "";
					for (++k; k < tmp.length(); ++k) {
						if (tmp.charAt(k) == ']')
							break;
						cond += tmp.charAt(k);
					}

					for (++k; k < tmp.length(); ++k) {
						if (tmp.charAt(k) <= '9' && tmp.charAt(k) >= '0')
							break;
					}
					num = "";
					for (; k < tmp.length(); ++k) {
						if (tmp.charAt(k) > '9' || tmp.charAt(k) < '0')
							break;
						num += tmp.charAt(k);
					}
					E.put(cond, new Integer(num));
				}
			}
		}

		System.out
				.println("          Decision | Cardinality of Decision Class | Cardinality of Lower Approximation | Cardinality of Upper Approximation");

		int Pos = 0;
		for (Map.Entry<String, ArrayList<String>> entry : Ass.entrySet()) {
			String Key = entry.getKey();
			ArrayList<String> Value = entry.getValue();
			int upperAx = 0, lowerAx = 0;
			for (int t = 0; t < Value.size(); ++t) {
				upperAx += E.get(Value.get(t));
				if (CountE.get(Value.get(t)) == 1) {
					lowerAx += E.get(Value.get(t));
				}
			}
			System.out.printf("%18s | %29d | %34d | %34d \n", Key, D.get(Key),
					lowerAx, upperAx);
			Pos += lowerAx;
		}
		System.out.println("The number of Positive Region:\t" + Pos);

		return 0;
	}
}



