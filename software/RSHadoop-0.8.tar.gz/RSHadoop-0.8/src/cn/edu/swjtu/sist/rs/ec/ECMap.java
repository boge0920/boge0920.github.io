/*
 * author:   Junbo Zhang
 * homepage: http://cs.gsu.edu/~jbzhang/
 * e-mail:   JunboZhang@163.com
 * paper:    Junbo Zhang, Tianrui Li, Da Ruan, Zizhe Gao, Chengbing Zhao, 
 *           A Parallel Method for Computing Rough Set Approximations, 
 *           Information Sciences, vol. 194, pp. 209-223, 2012.
 */

package cn.edu.swjtu.sist.rs.ec;

import java.io.*;
import java.util.ArrayList;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class ECMap extends Mapper<Object, Text, Text, IntWritable> {
	public void map(Object key, Text value, Context context)
			throws IOException, InterruptedException {
		String[] con_arr;
		ArrayList<String> con_list = new ArrayList<String>();
		int i = 0;
		con_arr = value.toString().split("(\\s*,\\s*|\\s+)");//
		String con, des;
		des = "[" + con_arr[con_arr.length - 1] + "]";
		IntWritable one = new IntWritable(1);
		int as, ae;
		String as_as, ae_ae;
		Configuration conf = context.getConfiguration();
		as_as = conf.get("as_as");
		as = Integer.parseInt(as_as);
		ae_ae = conf.get("ae_ae");
		ae = Integer.parseInt(ae_ae);
		if (as > 0 && as < con_arr.length && ae > 0) {
			con = "[" + con_arr[as - 1];
			int m_min = (con_arr.length - 1 < ae ? con_arr.length - 1 : ae);
			for (i = as; i < m_min; i++) {
				con += ',' + con_arr[i];
			}
			con += "]";
			context.write(new Text("e" + con), one);
			context.write(new Text("d" + des), one);
			context.write(new Text("F" + con + des), one);
		}
		con_list.clear();
	}
}