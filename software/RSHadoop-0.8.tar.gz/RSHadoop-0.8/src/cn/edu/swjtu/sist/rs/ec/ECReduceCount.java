/*
 * author:   Junbo Zhang
 * homepage: http://cs.gsu.edu/~jbzhang/
 * e-mail:   JunboZhang@163.com
 * paper:    Junbo Zhang, Tianrui Li, Da Ruan, Zizhe Gao, Chengbing Zhao, 
 *           A Parallel Method for Computing Rough Set Approximations, 
 *           Information Sciences, vol. 194, pp. 209-223, 2012.
 */
package cn.edu.swjtu.sist.rs.ec;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class ECReduceCount extends
		Reducer<Text, IntWritable, Text, IntWritable> {
	public void reduce(Text key, Iterable<IntWritable> values, Context context)
			throws IOException, InterruptedException {
		IntWritable result = new IntWritable();
		int sum = 0;
		for (IntWritable val : values) {
			sum += val.get();
		}
		result.set(sum);
		context.write(key, result);
	}
}
